# Siga rigorosamente as regras existentes neste arquivo

## Contexto geral da aplicação

- O sistema é um backend com objetivo de manipular containers dockers em uma máquina remota via API do Docker.
- Linguagem: TypeScript.
- Todo o código-fonte, mensagens de erro, respostas da API, nomes de classes, métodos e variáveis devem estar exclusivamente em inglês.
- Não é necessário criar frontend.

## Regras de Arquitetura do Projeto

- Este projeto segue rigorosamente os princípios de Clean Architecture.
- Cada camada deve estar totalmente desacoplada das demais.
- Utilize interfaces e o princípio da Inversão de Dependência (DIP).
- Classes devem depender apenas de abstrações, nunca de implementações concretas. Entidades (Entities) e Domain Services são as exceções que e podem ser utilizadas diretamente pelas demais camadas.
- Repositórios devem receber e devolver entidades prontas, em forma de objetos.
- Casos de uso não devem conhecer frameworks, banco de dados ou detalhes de infraestrutura.
- A nomeclatura das interfaces deve terminar com a palavra Interface, por exemplo, ProductRepositoryInterface.
- A interface dos Usecases (por exemplo, CreateProductUsecaseInterface) deve estar escrita no mesmo arquivo da implementação real da classe.
- Deve-se respeitar rigorosamente o princípio do encapsulamento: os atributos das entidades devem ser definidos como private, e o acesso ou modificação desses dados deve ocorrer exclusivamente por meio de métodos públicos (getters e setters) criados apenas quando houver real necessidade, evitando exposições desnecessárias do estado interno das entidades.
- Padrão de nomenclatura:  Utilize o padrão lower camelCase (também conhecido como camelCase simples) para a nomeação de variáveis, atributos, métodos e objetos, seguindo convenções semelhantes às adotadas na linguagem Java.
- A estrutura de diretórios da aplicação deve ser conforme abaixo.  Não crie subdiretórios dentro das pastas finais, a não ser que for explicitamente solicitado a fazer isso através do prompt.
  - src
  - src/domain
  - src/domain/entities
  - src/domain/value-objects     (se necessário)
  - src/domain/services          (Domain services, se necessário)
  - src/application
  - src/application/usecases
  - src/application/repositories (interfaces de repositories)
  - src/application/services     (interfaces de external/infra services, se necessário; Application Services, se necessário)
  - src/infra
  - src/infra/controllers
  - src/infra/repositories       (impl de repositories)
  - src/infra/services           (impl de external/infra services, se necessário)
  - src/infra/errors
  - src/factories


## Casos de uso e controllers
- Cada funcionalidade deve ter:
  - Um UseCase exclusivo, com um método principal chamado execute.
  - Um Controller exclusivo, com um método principal chamado handle
  - Exemplos:
    - Criar produto → CreateProductUseCase + CreateProductController
    - Apagar produto → DeleteProductUseCase + DeleteProductController
- Não reutilize controllers ou usecases para múltiplas responsabilidades.
- Os controllers devem depender apenas de abstrações dos usecases, nunca de implementações concretas.
- Todos os controllers do tipo create deverá retornar não apenas o código 201, mas os dados criados também.
- A comunicação entre o controller e o usecase deverá ser feita por DTOs.
- A declaração dos DTOs de entrada e saída do usecase deverá estar no mesmo arquivo do usecase.
- Um controller não deve ter acesso/manipular entidades nem domain services, apenas DTOs.

## Entidades
- O construtor das entidades deve ser privado.
- Cada entidade deverá ter um método chamado create que valida os dados de entrada de acordo com as regras de negócio e retorna um objeto da entidade. O objetivo é impedir a criação de objetos em estados inválidos. Em caso de erro, retorne um objeto do tipo Error.
- Cada entidade deverá ter um método chamado rebuild que retorna um objeto completo da entidade sem passar por nenhuma validação. Esse método deverá ser usado nos testes automatizados e quando necessitar construir um objeto vindo do banco de dados, por exemplo.
- As validações e regras de negócio devem ser distribuídas entre as entities, usecases e services, devendo estar nas entidades sempre que possível, a fim de evitar objetos inconsistentes.

## Banco de dados
- Banco de dados: SQLite3.
- Não utilize ORM (Prisma, TypeORM, Sequelize etc.).
- Os repositories devem manipular SQL diretamente.
- Deve existir um arquivo chamado docs/schema.sql contendo todo o código SQL necessário para criação das tabelas, relacionamentos e índices.
- Nenhuma regra de negócio deve ser inserida e executada diretamente pelo banco de dados, como exclusões em cascata (DELETE CASCADE), disparo de triggers, etc. Todas as regras de negócio devem estar no código da aplicação, com seus devidos testes automatizados.

## Configuração via .env
- Os seguintes valores devem ser lidos de um arquivo .env:
  - Caminho/nome do banco de dados real
  - Endereço do servidor do sistema atual
  - Porta da aplicação do sistema atual
  - Endereço do servidor Docker
  - Porta de comunicação do servidor Docker
  - Versão da API do Docker
  - Dados do servidor SMTP e credenciais relacionadas ao SMTP
    - SMTP_HOST=smtp.gmail.com
    - SMTP_PORT=587
    - SMTP_SECURE=false
    - SMTP_USER=seu_email@gmail.com
    - SMTP_PASSWORD=sua_senha_de_app_gmail
    - SMTP_FROM=seu_email@gmail.com
    - SMTP_FROM_NAME=Sistema de Containers Docker
  - Variáveis .env relacionadas ao JWT
    - JWT_SECRET=sua_chave_secreta_aqui_minimo_32_caracteres
    - JWT_EXPIRES_IN=24h
  - Variáveis relacionadas ao HTTPS
    - SSL_KEY_PATH
    - SSL_CERT_PATH

## Tratamento de erros
- A captura de exceções relacionados ao servidor, banco de dados e serviços externos (try/catch) deve ser feita dentro dos repositories e services
- Erros relacionados à infraestrutura devem ser tratados (utilização de try/catch) preferencialmente em repositories ou services, salvo raras exceções.
- Crie uma classe específica de erro chamada InfrastructureError dentro de src/infra/errors, que deverá ser usada quando o erro for relacionado a infraestrutura do servidor, banco de dados ou de serviços externos, principalmente em situações de exceções relacionadas a infraestrutura. A classe Error tradicional deverá ser usada sempre que ocorrer erro de regra de negócio ou validação.
- Você deve garantir, sempre que possível, que exceções relacionadas ao servidor, banco de dados e serviços externos não "vazem" para os usecases e controllers.
- Sempre que ocorrer um erro de negócio ou validação:
    - Retorne uma instância da classe Error
    - Evite lançar exceções diretamente (throw) sempre que possível

## Frameworks e infraestrutura
- Framework HTTP: Fastify (utilizado nos controllers)
  - Erros da classe Error devem gerar retorno HTTP do tipo 4xx.
  - Erros da classe InfrastructureError devem gerar retorno HTTP do tipo 5xx.
  - O formato padrão do JSON em casos de sucesso deve ser {"id": "...", "name": "...", ...}
  - O formato padrão do JSON em casos de erro deve ser { "message": "..." }. Neste caso, o cliente externo saberá que é um erro através da análise do código http retornado.
- Testes automatizados:
  - Framework: Jest
  - Cobertura exigida: 100%
  - Os arquivos index.ts e routes.ts não precisam ser cobertos por testes automatizados
- O sistema de login deverá usar JWT.
  - Gerenciamento de Sessão JWT:
    - Biblioteca: jsonwebtoken
    - Algoritmo: HS256 (HMAC com SHA-256)
    - Storage: Não utilizar storage de tokens (stateless JWT)
    - Tokens não são armazenados no servidor
    - Validação apenas pela assinatura e expiração
    - Logout apenas remove token do cliente (frontend)
- Utilize axios para se comunicar com a API do servidor Docker.

## Testes
- Todos os testes automatizados deverão estar no diretório test
- Os testes unitários deverão estar no diretório test/unit
- Os testes de integração deverão estar no diretório test/integration
- Sobre os testes unitários, a estrutura de diretórios dentro de test/unit deverá seguir a estrutura de diretórios de src
- Quando precisar criar um objeto de uma determinada entidade, se não existir necessidade de passar por validações, dê preferência ao método rebuild

## Testes unitários
- Os testes unitários devem cobrir não apenas o “caminho feliz”, mas todas os “outros caminhos”. Nesse ponto você deve ser rigoroso, garantindo que o teste unitário fornecido de fato cubra 100% da classe/método que está sendo testado.
- Devem cobrir: entities, domain services, value objects, usecases e controllers
- Não criar testes unitários para repositories, services de infra e factories, pois eles serão testados através dos testes de integração.

## Testes de integração
- Deve usar banco de dados em memória.
- Devem cobrir as respostas do controller (caminho feliz 2xx, e erros 4xx e 5xx).
- Devem ir desde o controller até o banco de dados real.
- Apenas request e response devem ser mockados nos testes de caminho feliz 2xx, e erros 4xx.
- Nos testes de erro de infraestrutura 5xx, o banco de dados e outros serviços de infraestrutura podem ser mockados.
- Deve ser possível de executar sem a necessidade de “subir” o servidor para executar os testes.
- Quando a funcionalidade estiver completa (por exemplo, Criar Produto), crie o teste de integração.

## arquivos src/index.ts e src/routes.ts
- O arquivo routes.ts deve:
  - Centralizar todas as rotas da aplicação.
  - Utilizar os factories existentes em src/factories para criar os controllers.
  - As rotas devem chamar diretamente o método handle de cada controller.
- O arquivo index.ts deve:
  - Centralizar toda a montagem da aplicação.
  - Deve usar o arquivo routes.ts
  - Subir o servidor utilizando endereço e porta fornecidos via .env
  - Se as variáveis de ambiente relacionadas ao SSL estiverem presentes no arquivo .env, a aplicação deverá usar HTTPS, caso contrário, HTTP.

## Documentação e testes manuais
- Deve existir um arquivo chamado docs/openapi.yaml contendo a documentação completa da API no formato OpenAPI (Swagger).
- Deve existir um arquivo chamado docs/api_curl_examples.txt contendo exemplos de chamadas usando curl, cobrindo todas as rotas da API, porém cobrindo apenas o caminho feliz.
- Esses dois arquivos (docs/openapi.yaml e docs/api_curl_examples.txt) devem ser mantidos sempre atualizados. Ao fim de cada interação, você deverá analisar se existe a necessidade de atualizar esses dois arquivos.

## Validação de segurança  (OWASP Top 10 - relevantes ao contexto) ao final da resposta

- Ao final de cada resposta, verifique se a implementação realizada naquela interação introduziu falhas de:
  - [ ] A01 - Broken Access Control: usuário só acessa/manipula seus próprios.
  - [ ] A02 - Security Misconfiguration: configurações de ambiente, headers, CORS, exposição de endpoints.
  - [ ] A04 - Cryptographic Failures: uso correto de bcrypt, JWT secret adequado, dados sensíveis não expostos.
  - [ ] A05 - Injection: queries SQL parametrizadas, inputs sanitizados antes de enviar a API externas.
  - [ ] A06 - Insecure Design: fluxos de autenticação, recuperação de senha e validação de email seguros.
  - [ ] A07 - Authentication Failures: JWT validado corretamente, email validado antes do login, proteção contra força bruta.
  - [ ] A10 - Mishandling of Exceptional Conditions: erros de infraestrutura não vazam detalhes internos ao cliente.
- Exiba um relatório de segurança no seguinte formato:
  - [X] A01 - Broken Access Control: OK / Nenhuma vulnerabilidade identificada
  - [X] A02 - Security Misconfiguration: OK / ...
  ...

## Validação final ao final da resposta, após a validação de segurança
- Ao final da sua execução, após a validação de segurança, você deverá verificar e emitir um relatório no formato abaixo:
  - [X] Solicitação do usuário implementada com sucesso.
    - Aqui você detalha tudo que foi realizado.
  - [X] A aplicação está compilando com sucesso.
  - [X] Todos os testes automatizados estão executando com sucesso.
  - [X] As camadas entities, domain services, usecases e controllers estão com 100% de cobertura de testes unitários.
  - [X] O arquivo docs/openapi.yaml está atualizado.
  - [X] O arquivo docs/api_curl_examples.txt está atualizado.
  - [X] O arquivo docs/schema.sql está atualizado.
  - [X] A aplicação passou na validação de segurança.

## Entidade User
- Crie as seguintes funcionalidades da entidade Product: Criar usuário, validar e-mail, trocar senha, atualizar nome, efetuar login
- Crie/atualize todos os arquivos necessários para que a backend seja executado com as funcionalidades relacionados ao User
- Campos:
  - id: string (Obrigatório, Não fornecido pelo usuário, Chave primária da tabela, uuid gerado pelo sistema no momento do cadastro, não pode ser alterado após a criação do User)
  - name: string (Obrigatório, Fornecido pelo usuário, Pode ser alterado após a criação do User)
  - email: string (Obrigatório, Fornecido pelo usuário, Deve obrigatoriamente terminar com @gsuite.iff.edu.br, não pode ser alterado após a criação do User)
  - password: string (Obrigatório, Fornecido pelo usuário, tamanho mínimo de 8 caracteres, Bcrypt, Pode ser alterado após a criação do User)
  - validatedEmail: boolean (Obrigatório, Não fornecido pelo usuário, Valor padrão false após a criação do User, O usuário só faz login/logout se validated for true)
  - validationCode: string (Obrigatório, Não fornecido pelo usuário, pequeno hash gerado automaticamente pelo usecase CreateUser, Enviado para o email do User pelo usecase CreateUser e deve ser utilizado para validar o User, Pode ser utilizado também na funcionalidade de esqueci minha senha)
- Funcionalidades relacionado ao User:
  - Criar Usuário: Cadastra o usuário no banco e envia um email contendo o código de validação.
  - Validar Usuário: Recebe o código de validação enviado por email e altera o validatedEmail para true.
  - Reenviar código para validar email: O usuário não validado e sem login solicita o reenvio do código de validação.
  - Esqueci minha senha: O usuário que já possui o email validado informa que esqueceu a senha, o sistema gera um novo hash, reaproveitando o campo validationCode e envia um link para o usuário trocar a senha.
  - Efetuar login: Usa o email e senha, só permitido se as credenciais estiverem certas e email validado.
  - Trocar senha: O User deve estar logado para poder trocar a senha.

## Entidade Container

- O User após logado poderá manipular containers (criar, listar, apagar, parar, iniciar) em um servidor Docker.
- O User só poderá manipular os seus próprios containers. Em hipótese nenhuma um User pode manipular um container de outro User.
- Naturalmente, só User autenticados podem manipular containers.
- Campos:
  - id: string (Obrigatório, Não fornecido pelo usuário, Chave primária da tabela, uuid gerado pelo sistema no momento do cadastro, não pode ser alterado após a criação do User)
  - userId: string (Obrigatório, Não fornecido pelo usuário, Deverá ser obtido pelo sistema através do User que está logado)
  - containerId: string (Obrigatório, Não fornecido pelo usuário, Deverá ser obtido pelo sistema através da resposta do servidor Docker que confirmou a criação do container)
  - image: string (Obrigatório, Fornecido pelo usuário)
  - IpAddress: string (Obrigatório, Não fornecido pelo usuário, Deverá ser obtido pelo sistema através da resposta do servidor Docker que confirmou a criação do container, Deverá ser sempre atualizado quando consulta o servidor Docker e verificado que o IpAddress do container mudou)
  - createDate: Date (Obrigatório, Não fornecido pelo usuário, Use a hora atual do servidor, Use o formato UTC (AAAA-MM-DDThh:mm:ssZ), Ignore fuso horários, use a data/hora que o servidor forneceu)
- Funcionalidades relacionado ao Container:
  - Ver todos os containers: O sistema busca no banco de dados a lista de todos os containers que o User tem cadastrado, em seguida, consulta o servidor Docker para verificar quais de fato existem. A funcionalidade retorna apenas a lista de containers do User que existem no servidor, assim como seu IpAddress e o status (ligado ou desligado). Não deve remover o registro do container no banco de dados. Caso o container esteja em execução e o IP address difere do que está no banco de dados, atualize o IP address no banco de dados. Uma observação importante sobre essa funcionalidade para você entender o contexto: o servidor Docker terá um script que apagará containers de tempos em tempos sem passar/informar a este sistema, logo, quando listar os containers do usuário no servidor, é capaz que containers que o usuário criou anteriormente não existirem mais. Nesse caso, essa funcionalidade apenas retorna os containers do User que ainda existem no servidor.
  - Criar Container: O usuário solicita a criação de um container, fornecendo a string da imagem base, e o backend envia uma solicitação de criar o container para o servidor Docker via API. Ao receber confirmação da criação do container no servidor Docker, o backend cadastra os dados no banco de dados e retorna os dados do banco de dados. Não há limites de criação de container por usuário.
  - Apagar Container: O usuário solicita e o sistema envia uma solicitação de apagar um container seu para o servidor Docker via API do servidor e ao receber confirmação da exclusão do container, entretanto não deve remover o registro do container no banco de dados, pois é necessário manter registrado que o User criou um container que possuia um determinado IP naquele determinado dia. Naturalmente, um User não pode apagar um container de outro usuário.
  - Iniciar Container: O usuário solicita e o sistema envia uma solicitação de ligar o container para o servidor Docker via API do servidor e ao receber confirmação da solicitação verifica se a operação foi realizada com sucesso. Caso ao iniciar o container o IP do container esteja diferente do que está cadastrado no banco de dados, atualize o IP no banco de dados.
  - Parar Container: O usuário solicita e o sistema envia uma solicitação de parar o container para o servidor Docker via API do servidor e ao receber confirmação da solicitação verifica se a operação foi realizada com sucesso.